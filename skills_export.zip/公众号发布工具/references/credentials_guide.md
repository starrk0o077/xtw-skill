# 微信公众号凭证配置指南

## 什么是 AppID 和 AppSecret？

- **AppID（应用ID）**：公众号的唯一标识
- **AppSecret（应用密钥）**：调用 API 的安全凭证，需妥善保管

## 获取步骤

### 1. 登录公众平台

访问 [微信公众平台](https://mp.weixin.qq.com)，使用管理员微信扫码登录。

### 2. 进入基本配置

路径：「设置与开发」→「基本配置」

### 3. 获取 AppID 和 AppSecret

- **AppID**：页面上直接可见
- **AppSecret**：点击「查看」按钮，需管理员验证后查看

### 4. 查询你的出口 IP

在「基本配置」页面找到「IP白名单」，需要填写你的服务器/电脑的出口 IP。

**查询方法**：

- **Windows PowerShell**：
  ```powershell
  (Invoke-WebRequest -Uri "https://api.ipify.org").Content
  ```
- **Linux/macOS 终端**：
  ```bash
  curl ifconfig.me
  ```
- **直接访问**：浏览器打开 https://api.ipify.org 或 https://ifconfig.me

将查到的 IP 添加到微信公众平台的「IP白名单」，否则所有 API 调用都会返回 40164 错误。

## 创建凭证文件

在工作目录创建 `wechat_credentials.json`：

```json
{
  "appid": "wx1234567890abcdef",
  "appsecret": "abcdef1234567890abcdef1234567890"
}
```

**注意**：
- 替换为你的实际 AppID 和 AppSecret
- 不要在代码中硬编码凭证
- 不要将凭证文件提交到 Git 仓库

## 哪些公众号类型支持 API？

| 类型 | AppID | API 发布 | 说明 |
|------|-------|---------|------|
| 已认证服务号 | ✅ | ✅ | 完整 API 功能 |
| 已认证订阅号 | ✅ | ✅ | 可发布草稿，但部分功能受限 |
| 未认证订阅号 | ❌ | ❌ | 无法获取 AppID |

## 安全建议

1. **不要分享 AppSecret**：AppSecret 等同于密码，泄露后他人可操作你的公众号
2. **定期更换**：如发现异常，在公众平台重置 AppSecret
3. **权限最小化**：使用专门的运营账号而非管理员账号

## 常见问题

### Q: 为什么我找不到 AppSecret？

只有管理员才能查看 AppSecret。如果是运营人员账号，请让管理员配置。

### Q: 重置 AppSecret 后需要更新什么？

更新 `wechat_credentials.json` 中的 appsecret 值即可。

### Q: 可以多人共用一个 AppID 吗？

可以，但需要注意：
- 所有操作都会以该 AppID 对应的公众号身份进行
- 建议记录操作日志
